---
"@tabler/preview": patch
---

Fix responsive layputs in 'Form Elements' page
