---
"@tabler/docs": patch
---

Fix Docs search in dark mode
