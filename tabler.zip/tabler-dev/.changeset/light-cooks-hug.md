---
"@tabler/preview": patch
---

Update icons to v3.34.1 (75 new icons)
