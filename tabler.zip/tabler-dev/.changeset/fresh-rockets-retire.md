---
"@tabler/core": patch
---

Fix mixed declarations in SCSS
