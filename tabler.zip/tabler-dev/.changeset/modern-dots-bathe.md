---
"@tabler/preview": patch
---

Update activity messages
