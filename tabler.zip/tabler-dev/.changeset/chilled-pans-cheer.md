---
"@tabler/preview": minor
---

Add a color palette in the signing component
