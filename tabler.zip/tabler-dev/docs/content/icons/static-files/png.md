---
title: PNG version
description: Download Tabler Icons in PNG format.
---

![](/img/icons/package-png.png)


## Installation

{% include "docs/tabs-package.html" name="@tabler/icons-png" %}

or just [download from Github](https://github.com/tabler/tabler-icons/releases).

All PNG files are stored in `icons` subdirectory.

## CDN

#### Outline version

```html
<img src="https://unpkg.com/@tabler/icons-png@$ICONS_VERSION/icons/outline/home.png" />
```

#### Filled version

```html
<img src="https://unpkg.com/@tabler/icons-png@$ICONS_VERSION/icons/filled/home.png" />
```

Instead of a specific version, you can use `latest` to always get the newest icons.