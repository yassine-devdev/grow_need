---
title: PDF version
description: Download Tabler Icons in PDF format.
---

![](/img/icons/package-pdf.png)


## Installation

{% include "docs/tabs-package.html" name="@tabler/icons-pdf" %}

or just [download from Github](https://github.com/tabler/tabler-icons/releases).

All PDF files are stored in `icons` subdirectory.
