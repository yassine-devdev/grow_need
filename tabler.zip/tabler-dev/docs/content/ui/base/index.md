---
title: Base
order: 2
description: Foundational elements for UI design.
summary: The base section includes foundational elements such as colors, typography, and spacing that form the building blocks of a cohesive and consistent user interface.
---