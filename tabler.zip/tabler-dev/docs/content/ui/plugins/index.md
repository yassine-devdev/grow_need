---
title: Plugins
order: 7
description: Enhance Tabler UI with useful plugins.
summary: Tabler plugins extend the functionality of the framework, providing additional tools and features to enhance your projects and streamline the development process.
---