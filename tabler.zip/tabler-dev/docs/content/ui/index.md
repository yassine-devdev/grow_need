---
title: Tabler UI
order: 1
description: Free and open source web application UI kit based on Bootstrap
summary: Tabler UI is a carefully crafted collection of modern and responsive user interface components. Built on top of Bootstrap, it helps developers create stunning and functional web applications quickly and efficiently.
---

![](/img/cover-tabler.png) 