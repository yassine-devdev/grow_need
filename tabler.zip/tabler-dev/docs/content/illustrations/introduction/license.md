---
title: Tabler Illustrations License
---

### Personal License

By purchasing Tabler Illustrations, you are granted an ongoing, non-exclusive license by codecalm.net to use Tabler Illustrations.

The license grants permission to one individual (the Licensee) to access and use the Tabler Illustrations.

You **can**:

* Use the Tabler Illustrations to create unlimited End Products.
* Modify the Tabler Illustrations to create derivative Tabler Illustrations. Those Tabler Illustrations are subject to this license.
* Use the Tabler Illustrations to create unlimited End Products for unlimited Clients.
* Use the Tabler Illustrations to create End Products where the End Product is sold to End Users.

You **cannot**:

* Use the Tabler Illustrations to create End Products that are designed to allow an End User to build their own End Products using the Tabler Illustrations or derivatives of the Tabler Illustrations.
* Re-distribute the Tabler Illustrations or derivatives of the Tabler Illustrations separately from an End Product, neither in code nor as design assets.
* Share your access to the Tabler Illustrations with any other individuals. You need a Team License for that to be allowed.
* Use the Tabler Illustrations to create End Products that are open source and freely available to End Users.
* Use the Tabler Illustrations to produce anything that may be deemed by codecalm.net, in their sole and absolute discretion, to be competitive or in conflict with the business of codecalm.net


#### Example usage

Examples of usage **allowed** by the license:* Creating a personal website by yourself.
* Creating a website or web application for a client that will be owned by that client.
* Creating a commercial SaaS application (like an invoicing app for example) where end users have to pay a fee to use the application.
* Creating a commercial self-hosted web application that is sold to end users for a one-time fee.

Examples of usage **not allowed** by the license:

* Creating a repository of your favorite Tabler Illustrations (or derivatives based on Tabler Illustrations) and publishing it publicly.
* Creating a UI library using Tabler Illustrations and making it available either for sale or for free.
* Converting a Tabler Illustrations to another framework and making it available either for sale or for free.
* Creating a Figma or Sketch file based on the Tabler Illustrations.
* Creating a "website builder" project where end users can build their own websites using illustrations included with or derived from Tabler Illustrations.
* Creating a theme, template, or project starter kit using the illustrations and making it available either for sale or for free.
* Creating a web application where the primary purpose is clearly not to simply re-distribute the illustrations (like a conference organization app that uses the illustrations for its UI for example) that is free and open source, where the source code is publicly available.

In simple terms, use Tabler Illustrations for anything you like as long as it doesn't compete with Tabler Illustrations.

### Team License

By purchasing Tabler Illustrations, you are granted an ongoing, non-exclusive license by codecalm.net to use Tabler Illustrations.

The license grants permission for up to 10 Employees and Contractors of the Licensee to access and use the Tabler Illustrations.

You **can**:

* Use the Tabler Illustrations to create unlimited End Products.
* Modify the Tabler Illustrations to create derivative Tabler Illustrations. Those Tabler Illustrations are subject to this license.
* Use the Tabler Illustrations to create unlimited End Products for unlimited Clients.
* Use the Tabler Illustrations to create End Products where the End Product is sold to End Users.

You **cannot**:

* Use the Tabler Illustrations to create End Products that are designed to allow an End User to build their own End Products using the Tabler Illustrations or derivatives of the Tabler Illustrations.
* Re-distribute the Tabler Illustrations or derivatives of the Tabler Illustrations separately from an End Product.
* Use the Tabler Illustrations to create End Products that are the property of any individual or entity other than the Licensee or Clients of the Licensee.
* Grant access to the Tabler Illustrations to individuals who are not an Employee or Contractor of the Licensee.
* Use the Tabler Illustrations to create End Products that are open source and freely available to End Users.
* Use the Tabler Illustrations to produce anything that may be deemed by codecalm.net, in their sole and absolute discretion, to be competitive or in conflict with the business of codecalm.net

#### Example usage

Examples of usage **allowed** by the license:

* Creating a website for your company.
* Creating a website or web application for a client that will be owned by that client.
* Creating a commercial SaaS application (like an invoicing app for example) where end users have to pay a fee to use the application.
* Creating a commercial self-hosted web application that is sold to end users for a one-time fee.

Examples of use **not allowed** by the license:

* Creating a repository of your favorite Tabler Illustrations (or derivatives based on Tabler Illustrations) and publishing it publicly.
* Creating a UI library using Tabler Illustrations and making it available either for sale or for free.
* Converting a Tabler Illustrations to another framework and making it available either for sale or for free.
* Creating a "website builder" project where end users can build their own websites using illustrations included with or derived from Tabler Illustrations.
* Creating a theme or template using the illustrations and making it available either for sale or for free.
* Creating any End Product that is not the sole property of either your company or a client of your company. For example your employees/contractors can't use your company Tabler Illustrations license to build their own websites or side projects.
* Giving someone access to Tabler Illustrations when they purchase a product from you. For example, you can't use a Team License as a way to give someone access to Tabler Illustrations when they purchase an online course from you.
* Selling access to your team account to people who don't work for you company.

---

In case of differences between above license agreements and the license agreements provided with the product, the license agreement provided with the product shall prevail.
