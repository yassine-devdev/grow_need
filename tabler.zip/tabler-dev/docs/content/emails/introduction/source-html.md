---
title: Source templates
order: 3
seoTitle: Tabler Emails - How to use the source HTML email templates
description: Learn how to use the source HTML email templates from the Tabler Emails package.
summary: The source HTML files from the Tabler Emails package need a bit more work than the compiled ones. Learn how to use them.
seoDescription: The source HTML files from the Tabler Emails package need a bit more work than the compiled ones. Learn how to use them.
---

## Source version of the template

If you want to make more advanced changes to the email template, you can use the source HTML files - `source.html` combined with the `theme.css` file. They are ready to use, but you need a basic knowledge of HTML and CSS to modify them.

## How to modify the source HTML files

1. Open the `source.html` file in your favorite code editor.
2. Open the `theme.css` file from the `assets/`* directory in the same editor.
3. Change all the content and styles as needed.
4. Use a selected tool to inline the CSS styles into the HTML file. There are a lot of options, such as:
* Online tools like [Juice](https://automattic.github.io/juice/) or [Mailchimp CSS Inliner Tool](https://templates.mailchimp.com/resources/inline-css/).
* NPM tools like [juice](https://www.npmjs.com/package/juice) or [inline-css](https://www.npmjs.com/package/inline-css).
5. Save the output HTML file.

## How to use the source HTML files

To use the modified HTML template send the output file with the `assets/` folder to your email marketing tool.